package com.example.speedneedle;

class gauges {
}
