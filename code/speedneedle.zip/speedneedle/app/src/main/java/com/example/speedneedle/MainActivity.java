package com.example.speedneedle;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.github.anastr.speedviewlib.SpeedView;

public class MainActivity extends gauges {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SpeedView speedometer = findViewById(R.id.speedometer);
    }
}
