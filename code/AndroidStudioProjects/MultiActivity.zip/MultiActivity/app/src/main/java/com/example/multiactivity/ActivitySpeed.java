package com.example.multiactivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ActivitySpeed extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_two);

        //int age= getIntent().getIntExtra("user-age", -1);
        //String name = getIntent().getStringExtra("User name");

        //TextView txtlabel = (TextView)findViewById(R.id.activity2);

        //txtlabel.setText("Your wheel size is " + age + ". Hi " + name);
        Intent intent = getIntent();
        String text  = intent.getStringExtra(MainActivity.EXTRA_TEXT);
        String text2  = intent.getStringExtra(MainActivity.EXTRA_TEXT2);

        TextView textView1 = (TextView) findViewById(R.id.textview1);
        TextView textView2 = (TextView) findViewById(R.id.textview2);

        textView1.setText("Hi " + text);
        textView2.setText("Your wheel size is " +text2 + "mm");

        //TextView txtlabel = (TextView)findViewById(R.id.);

        //txtlabel.setText("Your wheel size is " + text + ". Hi " + text2);
    }
}
