package com.example.multiactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    public static final String EXTRA_TEXT = "com.example.bike.EXTRA_TEXT";
    public static final String EXTRA_TEXT2 = "com.example.bike.EXTRA_TEXT2";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button = (Button) findViewById(R.id.button);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                openActivity2();
               /* Intent intent = new Intent(getApplicationContext(),ActivityTwo.class);
                intent.putExtra("user-age",30);
                intent.putExtra("user-name","shane");
                startActivity(intent);*/
            }
        });
    }

    public void openActivity2() {
        EditText editText1 = (EditText) findViewById(R.id.edittxt1);
        String text = editText1.getText().toString();

        EditText editText2 = (EditText) findViewById(R.id.edittxt2);
        String text2 = editText2.getText().toString();

        TextView textView = (TextView) findViewById(R.id.txtview1) ;
        textView.setText("Enter name + wheel size!");


        Intent intent = new Intent(this, ActivityTwo.class);
        intent.putExtra(EXTRA_TEXT, text);
        intent.putExtra(EXTRA_TEXT2, text2);
        startActivity(intent);
    }
}
