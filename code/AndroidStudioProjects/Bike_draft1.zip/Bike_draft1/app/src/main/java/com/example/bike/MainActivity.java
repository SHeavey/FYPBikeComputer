package com.example.bike;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    public static final String EXTRA_TEXT = "com.example.bike.EXTRA_TEXT";
    public static final String EXTRA_TEXT2 = "com.example.bike.EXTRA_TEXT2";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button = (Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivity2();
            }
        });
    }
    public void openActivity2() {
        EditText editText1 = (EditText) findViewById(R.id.edittxt1);
        String text = editText1.getText().toString();

        EditText editText2 = (EditText)  findViewById(R.id.edittxt2);
        String text2 = editText2.getText().toString();


        Intent intent = new Intent(this, Activity2.class);
        intent.putExtra(EXTRA_TEXT,text);
        intent.putExtra(EXTRA_TEXT2,text2);
        startActivity(intent);
    }
}